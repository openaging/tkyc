# reference: https://github.com/biopackathon/python-packaging-exercise/tree/main/poetry/mypackageabc/mypackageabc
from .my_module import *
__version__ = '0.1.0'